class RoutesName {
  static const String splashScreen   = 'splash_screen';
  static const String loginScreen    = 'login_screen';
  static const String otpScreen      = 'otp_screen';
  static const String dashboardScreen= 'dashborad_screen';

  // ✅ NEW
  static const String cartScreen     = 'cart_screen';
}
