// lib/models/update_customer_response_model.dart

class UpdateCustomerResponse {
  final CustomerData? data;
  final String? message;
  final bool succeeded;

  UpdateCustomerResponse({
    this.data,
    this.message,
    required this.succeeded,
  });

  factory UpdateCustomerResponse.fromJson(Map<String, dynamic> json) {
    return UpdateCustomerResponse(
      data: json['data'] != null ? CustomerData.fromJson(json['data']) : null,
      message: json['message'],
      succeeded: json['succeeded'] ?? false,
    );
  }
}

class CustomerData {
  final int id;
  final String customerName;
  final String emailId;
  final String phoneNumber;

  CustomerData({
    required this.id,
    required this.customerName,
    required this.emailId,
    required this.phoneNumber,
  });

  factory CustomerData.fromJson(Map<String, dynamic> json) {
    return CustomerData(
      id: json['id'] ?? 0,
      customerName: json['customerName'] ?? '',
      emailId: json['emailId'] ?? '',
      phoneNumber: json['phoneNumber'] ?? '',
    );
  }
}