class CustomerData {
  final int id;
  final String customerName;
  final String emailId;
  final String phoneNumber;

  CustomerData({
    required this.id,
    required this.customerName,
    required this.emailId,
    required this.phoneNumber,
  });

  factory CustomerData.fromJson(Map<String, dynamic> json) {
    return CustomerData(
      id: json['id'] as int,
      customerName: json['customerName'] as String,
      emailId: json['emailId'] as String,
      phoneNumber: json['phoneNumber'] as String,
    );
  }

  // Optional: A static method for an empty/default model state
  static CustomerData empty() => CustomerData(
    id: 0,
    customerName: 'N/A',
    emailId: 'N/A',
    phoneNumber: 'N/A',
  );
}

class CustomerResponse {
  final CustomerData? data;
  final bool succeeded;
  final String message;

  CustomerResponse({
    this.data,
    required this.succeeded,
    required this.message,
  });

  factory CustomerResponse.fromJson(Map<String, dynamic> json) {
    final dataJson = json['data'];
    return CustomerResponse(
      data: dataJson != null ? CustomerData.fromJson(dataJson) : null,
      succeeded: json['succeeded'] as bool,
      message: json['message'] as String,
    );
  }
}