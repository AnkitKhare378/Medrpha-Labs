// lib/models/AddressM/get_address_model.dart (CORRECTED)

import 'dart:convert';

List<UserAddress> userAddressFromJson(String str) =>
    List<UserAddress>.from(json.decode(str).map((x) => UserAddress.fromJson(x)));

String userAddressToJson(List<UserAddress> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class UserAddress {
  final int id;
  final int addressTypeId;
  final String? addressType;
  final String userId;
  final String? addressTitle;
  final String? faltHousNumber;
  final String street;
  final String locality;
  final String pincode;

  UserAddress({
    required this.id,
    required this.addressTypeId,
    this.addressType,
    required this.userId,
    this.addressTitle,
    this.faltHousNumber,
    required this.street,
    required this.locality,
    required this.pincode,
  });

  factory UserAddress.fromJson(Map<String, dynamic> json) => UserAddress(
    id: json["id"],
    addressTypeId: json["addressTypeID"],
    addressType: json["addressType"],
    userId: json["userId"],
    addressTitle: json["addressTitle"],
    faltHousNumber: json["faltHousNumber"],
    street: json["street"],
    locality: json["locality"],
    pincode: json["pincode"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "addressTypeID": addressTypeId,
    "addressType": addressType,
    "userId": userId,
    "addressTitle": addressTitle,
    "faltHousNumber": faltHousNumber,
    "street": street,
    "locality": locality,
    "pincode": pincode,
  };

  // Helper method to convert the model to a displayable map format
  Map<String, String> toDisplayMap() {
    String typeName;
    switch (addressTypeId) {
      case 5:
        typeName = 'Home';
        break;
      case 6:
        typeName = 'Office';
        break;
      case 7:
        typeName = 'Other';
        break;
      default:
        typeName = 'Unknown';
    }

    return {
      'title': addressTitle ?? "",
      'flat': faltHousNumber ?? "",
      'street': street,
      'locality': locality,
      'pincode': pincode,
      // 🛠️ CORRECTED: Use the derived typeName based on addressTypeId
      'type': typeName,
      'id': id.toString(),
      // 🛠️ CRITICAL FIX: Include addressTypeId for icon mapping in the UI
      'addressTypeId': addressTypeId.toString(),
    };
  }
}