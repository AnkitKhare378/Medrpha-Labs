import '../../../config/apiConstant/api_constant.dart';
import '../../../core/network/api_call.dart';
import '../../../models/AccountM/verify_otp_model.dart';

class VerifyOtpService {
  static Future<VerifyOtpModel> verifyOtp({
    required String input,
    required String otp,
  }) async {
    final bool isNumeric = RegExp(r'^[0-9]+$').hasMatch(input);
    final String url = isNumeric
        ? "${ApiConstants.baseUrl}Auth/VerifyOtp?phoneNumber=$input&otp=$otp"
        : "${ApiConstants.baseUrl}Auth/VerifyOtp?emailId=$input&otp=$otp";

    final response = await ApiCall.post(url, {});
    return VerifyOtpModel.fromJson(response);
  }
}
