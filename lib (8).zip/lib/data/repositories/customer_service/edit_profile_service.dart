import '../../../config/apiConstant/api_constant.dart';
import '../../../core/network/api_call.dart';
import '../../../models/CustomerM/update_customer_response_model.dart';

class EditProfileService {
  final String updateCustomerEndpoint = "${ApiConstants.baseUrl}MasterAPI/UpdateCustomer";

  Future<UpdateCustomerResponse> updateCustomer({
    required int id,
    required String customerName,
    required String emailId,
    required String phoneNumber,
  }) async {
    final Map<String, dynamic> body = {
      "id": id,
      "customerName": customerName,
      "emailId": emailId,
      "phoneNumber": phoneNumber,
    };

    try {
      final jsonResponse = await ApiCall.post(updateCustomerEndpoint, body);
      return UpdateCustomerResponse.fromJson(jsonResponse);
    } catch (e) {
      rethrow;
    }
  }
}