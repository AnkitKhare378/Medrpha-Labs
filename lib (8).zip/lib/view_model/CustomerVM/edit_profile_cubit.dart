// lib/view_model/ProfileVM/edit_profile_cubit.dart

import 'package:flutter_bloc/flutter_bloc.dart';
// NOTE: Remove unused 'dart:convert' and 'package:http/http.dart' as they are now in the service
import '../../data/repositories/customer_service/edit_profile_service.dart';
import '../../models/CustomerM/update_customer_response_model.dart';

// --- States (Remains the same) ---
abstract class EditProfileState {}

class EditProfileInitial extends EditProfileState {}
class EditProfileLoading extends EditProfileState {}
class EditProfileSuccess extends EditProfileState {
  final CustomerData customer;
  final String? message; // Added message from response
  EditProfileSuccess(this.customer, {this.message});
}
class EditProfileFailure extends EditProfileState {
  final String message;
  EditProfileFailure(this.message);
}

// --- Cubit (Updated) ---
class EditProfileCubit extends Cubit<EditProfileState> {
  // Cubit now holds a reference to the service
  final EditProfileService _service;

  EditProfileCubit(this._service) : super(EditProfileInitial());

  Future<void> updateCustomer({
    required int id,
    required String customerName,
    required String emailId,
    required String phoneNumber,
  }) async {
    emit(EditProfileLoading());

    try {
      // 1. Call the dedicated service method
      final UpdateCustomerResponse updateResponse = await _service.updateCustomer(
        id: id,
        customerName: customerName,
        emailId: emailId,
        phoneNumber: phoneNumber,
      );

      // 2. Process the response model
      if (updateResponse.succeeded && updateResponse.data != null) {
        // Successful API call and successful update logic
        emit(EditProfileSuccess(
          updateResponse.data!,
          message: updateResponse.message ?? updateResponse.message  ?? "Profile updated successfully.",
        ));
      } else {
        // API call succeeded (200) but the server reported a business logic failure
        emit(EditProfileFailure(
            updateResponse.message ?? updateResponse.message ?? "Update failed due to server logic."
        ));
      }
    } catch (e) {
      // This catches network errors and exceptions thrown by ApiCall.post
      emit(EditProfileFailure(e.toString().replaceFirst('Exception: ', '')));
    }
  }
}