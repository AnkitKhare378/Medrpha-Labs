part of 'address_type_view_model.dart';

abstract class AddressTypeEvent {}

class FetchAddressTypes extends AddressTypeEvent {}
