import 'package:equatable/equatable.dart';

abstract class VerifyOtpEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class VerifyOtpSubmitted extends VerifyOtpEvent {
  final String input;
  final String otp;

  VerifyOtpSubmitted(this.input, this.otp);

  @override
  List<Object?> get props => [input, otp];
}
