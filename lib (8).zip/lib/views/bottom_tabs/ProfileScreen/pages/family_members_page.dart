import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
// Note: Assuming necessary model and service imports are defined elsewhere
// and the imported cubits/states cover FamilyMemberDeleteState/Success/Error.

import '../../../../view_model/FamilyMemberVM/DeleteFamilyMember/family_member_delete_cubit.dart';
import '../../../../view_model/FamilyMemberVM/UpdateFamilyMember/family_member_update_cubit.dart';
import '../../../../view_model/FamilyMemberVM/get_family_members_view_model.dart'; // Contains GetFamilyMembersCubit/State
import '../../../Dashboard/widgets/slide_page_route.dart';
import '../../HomeScreen/pages/widgets/add_more_test_button.dart';
import '../widgets/family_member_shimmer.dart';
import 'add_member_page.dart';
import 'update_member_page.dart';

class FamilyMembersPage extends StatefulWidget {
  const FamilyMembersPage({super.key});

  @override
  State<FamilyMembersPage> createState() => _FamilyMembersPageState();
}

class _FamilyMembersPageState extends State<FamilyMembersPage> {
  static const Map<int, String> relationMap = {
    1: "Wife",
    2: "Other",
    3: "Sister",
    4: "Friend",
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<GetFamilyMembersCubit>().fetchFamilyMembers();
    });
  }

  String _calculateAge(DateTime birthDate) {
    DateTime today = DateTime.now();
    int age = today.year - birthDate.year;
    if (today.month < birthDate.month ||
        (today.month == birthDate.month && today.day < birthDate.day)) {
      age--;
    }
    return '$age yrs';
  }

  String _getRelationName(int relationId) {
    return relationMap[relationId] ?? 'Unknown';
  }

  Future<bool> _confirmDelete(BuildContext context, String name) async {
    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: Text('Confirm Deletion', style: GoogleFonts.poppins(fontWeight: FontWeight.w500),),
          content: Text('Are you sure you want to delete $name from your family members?',style:  GoogleFonts.poppins(fontSize: 14)),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text('Cancel', style: GoogleFonts.poppins(color: Colors.grey)),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: Text('Delete', style: GoogleFonts.poppins(color: Colors.redAccent)),
            ),
          ],
        );
      },
    ) ?? false;
  }

  Widget _memberCard({
    required String initial,
    required String name,
    required String relation,
    required String age,
    required double completion,
    required VoidCallback onTap,
    required VoidCallback onDelete,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade100,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: GestureDetector(
        onTap: onTap,
        child: Row(
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: Colors.blueAccent.withOpacity(0.15),
              child: Text(
                initial,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  color: Colors.blueAccent,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        name,
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        relation,
                        style: GoogleFonts.poppins(
                          color: Colors.blueAccent,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    'Age: $age',
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: completion,
                    minHeight: 6,
                    borderRadius: BorderRadius.circular(4),
                    backgroundColor: Colors.blueAccent.withOpacity(0.2),
                    valueColor: const AlwaysStoppedAnimation<Color>(
                      Colors.blueAccent,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Profile completion: ${(completion * 100).toInt()}%',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: onDelete,
              child: Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Icon(
                  Icons.delete,
                  size: 24,
                  color: Colors.redAccent,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F8),
      appBar: AppBar(
        title: Text(
          'Family Members',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: BlocListener<FamilyMemberDeleteCubit, FamilyMemberDeleteState>(
        listener: (context, state) {
          if (state is FamilyMemberDeleteSuccess) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message)),
            );
            context.read<GetFamilyMembersCubit>().refreshMembers();
          } else if (state is FamilyMemberDeleteError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message), backgroundColor: Colors.red),
            );
            // Optionally refresh to clear the list if the item visually disappeared
            context.read<GetFamilyMembersCubit>().refreshMembers();
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            children: [
              Expanded(
                child: BlocBuilder<GetFamilyMembersCubit, GetFamilyMembersState>(
                  builder: (context, state) {
                    if (state is GetFamilyMembersLoaded) {
                      if (state.members.isEmpty) {
                        return const Center(
                          child: Text('No family members found.'),
                        );
                      }

                      // Build the list from the fetched data
                      return ListView(
                        padding: const EdgeInsets.only(top: 16),
                        children: state.members.map((member) {
                          // Note: Ensure member.id is available from the model
                          final memberId = member.id;
                          String initial = member.firstName.isNotEmpty
                              ? member.firstName[0].toUpperCase()
                              : '?';
                          // member.dateOfBirth is DateTime assumed from your code
                          String age = _calculateAge(member.dateOfBirth);
                          double completion = 0.8; // Placeholder

                          String relationName = _getRelationName(
                            member.relationId,
                          );
                          return Dismissible(
                            key: ValueKey(memberId),
                            direction: DismissDirection.endToStart,
                            background: Container(
                              alignment: Alignment.centerRight,
                              padding: const EdgeInsets.only(right: 20.0),
                              decoration: BoxDecoration(
                                color: Colors.red.shade600,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              margin: const EdgeInsets.only(bottom: 16), // Margin added here
                              child: const Icon(Icons.delete, color: Colors.white),
                            ),
                            confirmDismiss: (direction) async {
                              return await _confirmDelete(context, member.firstName);
                            },
                            onDismissed: (direction) {
                              context.read<FamilyMemberDeleteCubit>().deleteMember(memberId);
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 16), // Apply card spacing here
                              child: _memberCard(
                                initial: initial,
                                name: '${member.firstName} ${member.lastName}',
                                relation: relationName,
                                age: age,
                                completion: completion,
                                // Navigation logic for card body tap
                                onTap: () async {
                                  context.read<FamilyMemberUpdateCubit>().resetState();
                                  await Navigator.of(context).push(
                                    SlidePageRoute(
                                      page: UpdateMemberPage(member: member),
                                    ),
                                  );
                                  context.read<GetFamilyMembersCubit>().refreshMembers();
                                },
                                // Delete logic for icon tap
                                onDelete: () async {
                                  if (await _confirmDelete(context, member.firstName)) {
                                    context.read<FamilyMemberDeleteCubit>().deleteMember(memberId);
                                  }
                                },
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    }

                    // Handle loading and error states below
                    if (state is GetFamilyMembersLoading || state is GetFamilyMembersInitial) {
                      return const FamilyMemberShimmer();
                    }

                    if (state is GetFamilyMembersError) {
                      return Center(child: Text('Error: ${state.message}'));
                    }

                    return const SizedBox.shrink();
                  },
                ),
              ),

              AddMoreTestButton(
                onPressed: () async {
                  // Refresh the list when returning from add screen
                  await Navigator.of(
                    context,
                  ).push(SlidePageRoute(page: const AddNewMemberPage()));
                  context.read<GetFamilyMembersCubit>().refreshMembers();
                },
                title: '+ Add new member',
                backgroundColor: Colors.blueAccent, textColor: Colors.white,borderColor: Colors.blueAccent,
              ),
              const SizedBox(height: 10,)
            ],
          ),
        ),
      ),
    );
  }
}