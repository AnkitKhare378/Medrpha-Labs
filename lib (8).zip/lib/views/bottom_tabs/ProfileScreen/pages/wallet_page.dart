// lib/screens/wallet/wallet_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../../../../models/WalletM/wallet_model.dart';
import '../../../../view_model/WalletVM/wallet_bloc.dart';
import '../../../../view_model/WalletVM/wallet_event.dart';
import '../../../../view_model/WalletVM/wallet_state.dart';
import '../../HomeScreen/pages/widgets/add_more_test_button.dart';

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});

  String _formatCurrency(double amount) {
    final formatter = NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 2,
    );
    return formatter.format(amount);
  }

  @override
  Widget build(BuildContext context) {
    context.read<WalletBloc>().add(const FetchWalletData());

    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F8),
      appBar: AppBar(
        title: Text('My wallet',
            style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Wallet Total Section (Dynamic Content)
            BlocBuilder<WalletBloc, WalletState>(
              builder: (context, state) {
                if (state is WalletLoading) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is WalletError) {
                  return Center(child: Text('Error: ${state.message}', style: const TextStyle(color: Colors.red)));
                } else if (state is WalletLoaded) {
                  return _buildWalletCard(state.walletData);
                }
                // Initial or other states show the default card
                return _buildWalletCard(null);
              },
            ),

            const SizedBox(height: 24),

            // Add NMS Cash (Static Content)
            Text('Add Medr Cash',
                style: GoogleFonts.poppins(
                    fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            _buildAddCashSection(),
            const SizedBox(height: 16),
            Text(
              'Note: The cash will be added to Medr Cash and can be used only for purchases on Medrpha Labs. '
                  'The money added cannot be transferred to any other wallet and bank account. Terms & Conditions',
              style: GoogleFonts.poppins(fontSize: 13, color: Colors.blueAccent, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 20),

            // Transactions Tabs (Static Content)
            _buildTransactionTabs(),
          ],
        ),
      ),
    );
  }

  // --- Widget Builders ---

  Widget _buildWalletCard(WalletData? data) {
    final balance = data?.currentBalance ?? 0.00;
    final formattedBalance = _formatCurrency(balance);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade100,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text('Wallet Total',
              style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[700])),
          const SizedBox(height: 4),
          Text(formattedBalance,
              style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  color: Colors.blueAccent)),
          const Divider(height: 28),
          _walletRow('Medr Cash', formattedBalance), // Assuming currentBalance reflects Medr Cash
          _walletRow('Medr Supercash', _formatCurrency(0.00)), // Hardcoded for supercash as it's not in API
        ],
      ),
    );
  }

  Widget _walletRow(String title, String amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style: GoogleFonts.poppins(
                  fontSize: 15, fontWeight: FontWeight.w500)),
          Text(amount,
              style: GoogleFonts.poppins(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Colors.blueAccent)),
        ],
      ),
    );
  }

  Widget _buildAddCashSection() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade100,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          TextFormField(
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: '₹',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 6,
            children: ['+400', '+500', '+1000', '+2000']
                .map((v) => Chip(
              label: Text(v,
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w500,
                      color: Colors.blueAccent, fontSize: 12)),
              backgroundColor:
              Colors.white,
            ))
                .toList(),
          ),
          const SizedBox(height: 20),
          AddMoreTestButton(
            onPressed: () async {},
            title: "ADD TO WALLET",
            backgroundColor: Colors.grey.shade300, textColor: Colors.black87,
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionTabs() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {},
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.blueAccent,
              side: const BorderSide(color: Colors.blueAccent),
            ),
            child: Text('Medr Cash',
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 12)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton(
            onPressed: () {},
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.blueAccent,
              side: const BorderSide(color: Colors.blueAccent),
            ),
            child: Text('Medr Supercash',
                style: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 12)),
          ),
        ),
      ],
    );
  }
}