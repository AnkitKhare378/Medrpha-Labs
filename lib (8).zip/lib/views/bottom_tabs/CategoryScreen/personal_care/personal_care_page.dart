import 'package:flutter/material.dart';

class PersonalCarePage extends StatefulWidget {
  const PersonalCarePage({super.key});

  @override
  State<PersonalCarePage> createState() => _PersonalCarePageState();
}

class _PersonalCarePageState extends State<PersonalCarePage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
