import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_bloc/flutter_bloc.dart'; // REQUIRED
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/repositories/payment_method_service/payment_service.dart'; // REQUIRED
import '../../../models/device_product.dart';
import '../../../pages/dashboard/bloc/dashboard_bloc.dart';
import '../../../pages/dashboard/bloc/dashboard_event.dart';
import '../../../view_model/PaymentVM/payment_cubit.dart'; // REQUIRED
import '../../../view_model/PaymentVM/payment_state.dart'; // REQUIRED
import '../../Dashboard/widgets/slide_page_route.dart';
import '../HomeScreen/pages/select_address_page.dart';
import 'store/cart_notifier.dart';
import 'widgets/cart_bottom_bar.dart';
import 'widgets/cart_header.dart';
import 'widgets/cart_product_card.dart';
import 'widgets/empty_cart_section.dart';
import 'widgets/payment_details_card.dart';

class MyCartPage extends StatefulWidget {
  const MyCartPage({Key? key}) : super(key: key);

  @override
  State<MyCartPage> createState() => _MyCartPageState();
}

class _MyCartPageState extends State<MyCartPage> {
  String selectedAddress =
      'Flat No. 12B, Sai Residency Apartments,\nAnna Nagar 4th Avenue,\nChennai – 600040'; // ✅ Default

  int? userId;

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('user_id');

    if (mounted) {
      setState(() {
        userId = id;
      });
    }
  }

  Widget _buildSectionHeading(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
      child: Text(
        title,
        style: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.black87,
        ),
      ),
    );
  }

  final Map<int, String> categoryNames = {
    1: "Products",
    2: "Services",
    3: "Packages"
  };

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => PaymentCubit(context.read<PaymentService>())..fetchPaymentMethods(),
      child: Builder(
        builder: (context) {
          final cart = context.watch<CartProvider>();
          final int cartId = cart.apiCartId;
          final totalAmount = cart.totalPayable;
          final groupedItems = cart.items.values.where((item) => item.qty > 0).fold<Map<int, List<CartItem>>>(
            {},
                (map, item) {
              map.putIfAbsent(item.categoryId, () => []).add(item);
              return map;
            },
          );

          final List<Widget> cartWidgets = [];
          final sortedCategoryIds = groupedItems.keys.toList()..sort();

          for (final categoryId in sortedCategoryIds) {
            final items = groupedItems[categoryId]!;
            final categoryTitle = categoryNames[categoryId] ?? "Category $categoryId";
            cartWidgets.add(_buildSectionHeading(categoryTitle));
            cartWidgets.add(const Divider(height: 1, thickness: 0.5));
            for (final item in items) {
              final product = DeviceProduct(
                name: item.name,
                imageUrl: 'https://via.placeholder.com/150',
                originalPrice: item.originalPrice,
                discountedPrice: item.discountedPrice,
                discountPercentage: '',
                category: '',
                isSaved: false,
              );
              cartWidgets.add(CartProductCard(product: product));
            }
          }

          return SafeArea(
            top: false,
            child: Scaffold(
              backgroundColor: AppColors.backgroundColor,
              appBar: CartHeader(
                onBack: () {
                  context.read<DashboardBloc>().add(DashboardTabChanged(0));
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
              ),
              body: cart.items.isEmpty
                  ? const EmptyCartSection()
                  : ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  ...cartWidgets,
                  const SizedBox(height: 8),
                  const PaymentDetailsCard(),
                  const SizedBox(height: 80),
                ],
              ),
              bottomNavigationBar: cart.items.isEmpty
                  ? null
                  : CartBottomBar(
                userId : userId ?? 0,
                cartId: cartId,
                subTotal: 2,
                discountAmount: 0,
                totalAmount: totalAmount.toDouble(),
                deliveryAddress: selectedAddress,
                onChangeAddress: () async {
                  final result = await Navigator.of(context).push(
                    SlidePageRoute(page: const SelectAddressPage()),
                  );
                  if (result != null && mounted) {
                    setState(() {
                      selectedAddress = result['address']!;
                    });
                  }
                },
              ),
            ),
          );
        },
      ),
    );
  }
}