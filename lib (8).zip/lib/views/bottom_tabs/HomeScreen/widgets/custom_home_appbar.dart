import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:medrpha_labs/view_model/CustomerVM/customer_state.dart';
import 'package:medrpha_labs/views/Dashboard/pages/app_drawer.dart';
import 'package:medrpha_labs/views/Dashboard/pages/notification_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../models/CustomerM/customer_model.dart';
import '../../../../view_model/CustomerVM/customer_bloc.dart';
import '../../../../view_model/CustomerVM/customer_event.dart';
import '../../../Dashboard/widgets/slide_page_route.dart';

class CustomHomeAppBar extends StatefulWidget implements PreferredSizeWidget {
  final String location;

  const CustomHomeAppBar({
    super.key,
    required this.location,
  });

  @override
  State<CustomHomeAppBar> createState() => _CustomHomeAppBarState();

  @override
  Size get preferredSize => const Size.fromHeight(80);
}

class _CustomHomeAppBarState extends State<CustomHomeAppBar> {
  String? _selectedLabName;
  int? _customerId;

  @override
  void initState() {
    super.initState();
    _loadUserIdAndDispatchCustomerEvent();
    _loadSelectedLab();
  }

  Future<void> _loadSelectedLab() async {
    final prefs = await SharedPreferences.getInstance();
    final labName = prefs.getString('selectedLabName');
    setState(() {
      _selectedLabName = labName;
    });
  }

  Future<void> _loadUserIdAndDispatchCustomerEvent() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getInt('user_id');
    print(userId);
    if (mounted) {
      setState(() {
        _customerId = userId ?? 0;
      });
      context.read<CustomerBloc>().add(FetchCustomerEvent(_customerId!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CustomerBloc, CustomerState>(
      builder: (context, state){
        String userName = 'User';
        CustomerData? customerData;
        if (state is CustomerLoaded) {
          userName = state.customer.customerName;
          customerData = state.customer;
        } else if (state is CustomerLoading) {
          userName = 'Loading...';
        } else if (state is CustomerError) {
          print('Customer fetch error: ${state.message}');
        }
        String getFirstName(String fullName) {
          if (fullName.trim().isEmpty) {
            return 'User';
          }
          return fullName.split(' ').first;
        }
        String firstName = getFirstName(userName);
        return AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
          elevation: 0,
          toolbarHeight: 80,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome, $firstName',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Row(
                    children: [
                      Text(
                        'Location: ',
                        style: GoogleFonts.poppins(
                          fontSize: 10,
                          color: Colors.grey[700],
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            widget.location,
                            style: GoogleFonts.poppins(
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              color: Colors.blueAccent,
                            ),
                          ),
                          // const Icon(Icons.keyboard_arrow_down_rounded, size: 15),
                          // const SizedBox(width: 4),
                          // Text(
                          //   _selectedLabName ?? "Select Lab",
                          //   style: GoogleFonts.poppins(
                          //     fontSize: 10,
                          //     fontWeight: FontWeight.w500,
                          //     color: Colors.black,
                          //   ),
                          // ),
                        ],
                      )
                    ],
                  ),
                ],
              ),

              // Right Side: Notification & Select Labs
              Row(
                children: [
                  IconButton(
                    icon: const Icon(FontAwesomeIcons.bell, size: 16,),
                    color: Colors.black,
                    onPressed: () {
                      Navigator.of(context).push(
                        PageRouteBuilder(
                          pageBuilder: (context, animation, secondaryAnimation) =>
                          const NotificationPage(),
                          transitionsBuilder: (context, animation, secondaryAnimation, child) {
                            const begin = Offset(1.0, 0.0);
                            const end = Offset.zero;
                            const curve = Curves.easeInOut;

                            var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
                            return SlideTransition(
                              position: animation.drive(tween),
                              child: child,
                            );
                          },
                        ),
                      );
                    },
                  ),
                  // IconButton(onPressed: (){
                  //   Navigator.of(context).push(
                  //     SlidePageRoute(
                  //         page: AppDrawer()
                  //     ),
                  //   );
                  // }, icon: const Icon(FontAwesomeIcons.bars, size: 16,),)
                  // IconButton(
                  //   icon: const Icon(FontAwesomeIcons.houseMedical, size: 16,),
                  //   color: Colors.black,
                  //   tooltip: 'Select Labs',
                  //   onPressed: () async {
                  //     final labs = [
                  //       {"name": "Medrpha Labs - New", "location": "123 Main Street"},
                  //       {"name": "Medrpha Labs - North", "location": "45 Elm Avenue"},
                  //       {"name": "Medrpha Labs - West", "location": "78 Pine Road"},
                  //     ];
                  //
                  //     final selectedLab = await showDialog(
                  //       context: context,
                  //       builder: (_) => LabsListDialog(labs: labs),
                  //     );
                  //
                  //     if (selectedLab != null) {
                  //       setState(() {
                  //         _selectedLabName = selectedLab['name'];
                  //       });
                  //     }
                  //   },
                  // ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
