import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class AdvBanner extends StatefulWidget {
  const AdvBanner({super.key});

  @override
  State<AdvBanner> createState() => _AdvBannerState();
}

class _AdvBannerState extends State<AdvBanner> {
  final PageController _controller = PageController();

  final List<String> banners = [
    "https://t4.ftcdn.net/jpg/02/38/70/67/360_F_238706716_aKnllr4AbeSc0wXX7YnwCjYx3K2MvbFL.jpg",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQRSHbXd8d7Gh2YQSbCRT2XwWj8NUtXMFbFuQ&s",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaRrCdqTY7Tz3blqJUplABDs2y0aDmY6nd_A&s",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSINs7-sv-Kl_Ej8H2q5XJLPvbdjHytvB6cbQ&s",
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _controller,
            itemCount: banners.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.network(
                    banners[index],
                    fit: BoxFit.cover,
                    width: double.infinity,
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        SmoothPageIndicator(
          controller: _controller,
          count: banners.length,
          effect: ExpandingDotsEffect(
            dotHeight: 8,
            dotWidth: 8,
            activeDotColor: Colors.blue,
            dotColor: Colors.grey.shade300,
          ),
        ),
      ],
    );
  }
}
