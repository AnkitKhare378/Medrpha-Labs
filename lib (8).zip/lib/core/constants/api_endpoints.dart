class ApiEndpoints {
  static const baseUrl = "https://example.com/api";
  static const login = "$baseUrl/login";
  static const users = "$baseUrl/users";
}