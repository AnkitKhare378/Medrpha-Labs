class AppStrings {
  static const appName = "My App";
  static const noInternet = "No internet connection.";
  static const somethingWentWrong = "Something went wrong. Please try again.";
}